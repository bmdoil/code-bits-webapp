CREATE DATABASE server_prod;
CREATE DATABASE server_dev;
CREATE DATABASE server_test;