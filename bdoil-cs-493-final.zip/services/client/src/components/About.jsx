import React from 'react';

const About = () => (
    <div>
        <h1 className="title is-1">Welcome to Code-Bites</h1>
        <h3 className="title is-3"> Brent Doil's CS493 Final Project</h3>
        <hr/><br/>
        <p>Full API documentation is available by clicking API above.</p>  
    </div>
)

export default About